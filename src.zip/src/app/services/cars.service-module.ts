import { NgModule } from '@angular/core';
import { CarsService } from './cars.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [CarsService],
  exports: []
})
export class CarsServiceModule {
}
