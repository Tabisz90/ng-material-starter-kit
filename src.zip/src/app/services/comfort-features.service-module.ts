import { NgModule } from '@angular/core';
import { ComfortFeaturesService } from './comfort-features.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [ComfortFeaturesService],
  exports: []
})
export class ComfortFeaturesServiceModule {
}
