import { NgModule } from '@angular/core';
import { SecurityFeaturesService } from './security-features.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [SecurityFeaturesService],
  exports: []
})
export class SecurityFeaturesServiceModule {
}
