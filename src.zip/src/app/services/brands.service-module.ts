import { NgModule } from '@angular/core';
import { BrandsService } from './brands.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [BrandsService],
  exports: []
})
export class BrandsServiceModule {
}
