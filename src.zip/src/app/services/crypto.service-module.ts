import { NgModule } from '@angular/core';
import { CryptoService } from './crypto.service';

@NgModule({
  imports: [],
  declarations: [],
  providers: [CryptoService],
  exports: []
})
export class CryptoServiceModule {
}
