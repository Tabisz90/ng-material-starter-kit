export interface CarView {
  readonly brand: string;
  readonly model: string;
  readonly securityFeatures: string[];
  readonly comfortFeatures: string[];
}
