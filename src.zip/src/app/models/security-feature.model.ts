export interface SecurityFeatureModel {
  readonly name: string;
  readonly id: string;
}
