export interface BrandModel {
  readonly name: string;
  readonly id: string;
}
